/* randarg.c - Tests the randomisation of arguments/environment
 * 
 */

#ifndef RUNDIR
#error RUNDIR not defined
#endif

const char testname[] = "Arg/env randomisation test (SEGMEXEC)    ";
const char testprog[] = RUNDIR"/getarg1";
